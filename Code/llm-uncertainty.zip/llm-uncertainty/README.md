# llm-uncertainty

Ask LLMs multiple-choice questions through [OpenRouter](https://openrouter.ai), record the
**token log-probabilities** behind each answer, and turn them into uncertainty measures:
confidence, probit, entropy, Brier score, calibration error (ECE) and AUROC. Every call is logged,
failed calls are retried, and an interrupted run can be resumed without repeating work.

Two ways to run the models:

| Backend | Config | Cost | Models |
|---|---|---|---|
| **Local / Google Colab** (Hugging Face) | `config.colab.toml` | Free (your GPU or Colab's free T4) | Gemma 4 12B / E4B (Google), gpt-oss-20b (OpenAI) |
| **OpenRouter API** | `config.toml` | Fractions of a cent per run | gpt-oss-120b (OpenAI), DeepSeek V4 Flash |

## Quickest start: Google Colab (free)

1. Open `colab/llm_uncertainty_colab.ipynb` in [Google Colab](https://colab.research.google.com)
   (*File → Upload notebook*, or *GitHub* tab if this repo is on GitHub).
2. *Runtime → Change runtime type → T4 GPU*.
3. Run the cells top to bottom. Cell 2 asks for `llm-uncertainty.zip` (or your repo URL).

The local backend reads the model's full output distribution, so the probability of **every** option
letter is exact, not limited to the top-k tokens an API returns.

## Setup

Requires Python 3.11+.

```bash
git clone <this repo> && cd llm-uncertainty
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then paste your OpenRouter key into .env
```

## Run a test

```bash
# check inputs and see the exact prompt, no API calls
python -m llmtest run -q questions/example.csv --dry-run

# quick 3-question smoke test
python -m llmtest run -q questions/example.csv --limit 3

# full run
python -m llmtest run -q questions/example.csv --name my-first-run
```

Each run writes to `results/<name>/`:

| File | What's in it |
|---|---|
| `report.md` | Readable write-up: summary table per model, per-question answers and confidences, errors |
| `summary.csv` | One row per answer, for Excel / pandas / R |
| `raw.jsonl` | Every API call, including the full raw response and logprobs |
| `run_meta.json` | Config, questions-file hash, git commit, and each run session |

Rebuild the report at any time with `python -m llmtest report results/my-first-run`.

### Reliability

- **Pacing:** requests are spaced to stay under the rate limit (`requests_per_minute`).
- **Retries:** 429s, 5xx errors, timeouts and empty responses are retried with exponential backoff,
  honouring `Retry-After`.
- **Logprobs routing:** `require_parameters = true` makes OpenRouter use only providers that return logprobs.
- **Resume:** results are saved after every call. If a run stops (daily limit, Ctrl-C, network),
  run the same command with the same `--name` and it picks up where it left off, retrying only failed calls.
- **Reproducibility:** the questions file is hashed; resuming with an edited file is refused.

## Your own questions

CSV, with any number of option columns named `A`, `B`, `C`, …; `answer` and `category` are optional:

```csv
id,category,question,A,B,C,D,answer
q01,geography,What is the capital of Australia?,Sydney,Canberra,Melbourne,Perth,B
```

or JSONL:

```json
{"id": "q01", "question": "What is the capital of Australia?", "options": {"A": "Sydney", "B": "Canberra"}, "answer": "B"}
```

Leave `answer` blank for questions with no right answer (opinion, ambiguous); you still get
confidence and entropy, just not accuracy or calibration.

### The "not sure" option

If your questions include a "not sure / insufficient information" option (default letter `E`), you
can choose whether the model sees it:

```bash
python -m llmtest run -q questions/veterinary_sample_15.csv --not-sure offer --name vet-offer
python -m llmtest run -q questions/veterinary_sample_15.csv --not-sure hide  --name vet-hide
```

or set `offer_not_sure` / `not_sure_option` under `[run]` in the config. When **hidden**, the option is
removed from every question, and any question whose correct answer *is* that option is skipped and
listed in the report. When **offered**, the report adds *Not sure chosen*, *Mean p(not sure)* (probability on
the option even when not picked) and *Accuracy when answered*. A run can't be resumed with the other
setting, so each setting gets its own run name. To compare like with like, compare the questions
both runs share (the Colab notebook does this for you).

## Choosing models

```bash
python -m llmtest models                   # every model with logprobs support, with prices
python -m llmtest models --free            # free ones only
python -m llmtest models --search deepseek
```

Edit `[[models]]` in `config.toml`. Use `--models openai/gpt-oss-120b` to run a subset.
Notes:
- Reasoning models (e.g. gpt-oss) think before answering, so give them a bigger `max_tokens`.
  The logprobs are taken at the first answer-letter token of the final reply.
- Free (`:free`) models are limited to 20 requests/min and 50/day, or 1,000/day once you've bought
  $10 of credits. Paid open-weight models such as the defaults cost fractions of a cent per run.

## Running Hugging Face models yourself

On any machine with an NVIDIA GPU (≥16 GB for the defaults):

```bash
pip install -r requirements-hf.txt
python -m llmtest run -c config.colab.toml -q questions/example.csv --models "Gemma 4 12B"
```

Add any Hugging Face chat model as a `[[models]]` entry. Options for this backend:
`quantization` (`4bit`/`8bit`), `dtype`, `chat_template_kwargs`, `answer_marker` (score only text after
this marker, e.g. after a reasoning block) and `assistant_prefill`. See `config.colab.toml` for worked examples.

## Run it from GitHub (no local setup)

1. Push this repo to GitHub.
2. In **Settings → Secrets and variables → Actions**, add `OPENROUTER_API_KEY`.
3. In **Actions → Run uncertainty test → Run workflow**, choose a questions file.

The report appears in the job summary, the results folder is attached as an artifact, and
(optionally) committed to `results/`. From the command line:

```bash
gh workflow run run-test.yml -f questions=questions/example.csv -f commit_results=true
```

## Call it from Python

```python
from llmtest.api import run_questions
run_dir = run_questions("questions/example.csv", name="from-python")
print((run_dir / "report.md").read_text())
```

## What the measures mean

| Measure | Meaning |
|---|---|
| **p (confidence)** | Probability on the chosen option, renormalised over the valid letters |
| **Probit** | Φ⁻¹(p): confidence on a z-score scale (0 = 50/50, 2.33 ≈ 99%) |
| **Entropy** | Spread of probability over options, in bits (0 = certain) |
| **Margin** | Gap between the top two options |
| **Option mass** | Share of total probability on valid letters (low = the model wanted to say something else) |
| **Brier** | Squared error of the whole option distribution vs the right answer |
| **ECE** | Average gap between confidence and actual accuracy |
| **AUROC** | How well confidence separates right from wrong answers |
| **Stated conf.** | Second call: the model sees its own answer and is asked "How confident are you (0-100)?"; the number it gives, as 0-1 (`stated_conf` in summary.csv). Turn off with `ask_confidence = false` |
| **ρ token↔stated** | Rank correlation between token confidence (p) and stated confidence: do they agree on which answers are shaky? |

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```
