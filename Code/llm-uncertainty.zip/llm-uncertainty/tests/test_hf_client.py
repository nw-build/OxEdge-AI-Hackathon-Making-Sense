"""End-to-end test of the local Hugging Face backend with a tiny random model (CPU, ~a few MB download).

Skipped automatically if torch/transformers aren't installed or the model can't be downloaded.
"""
from pathlib import Path

import pytest

pytest.importorskip("torch")
pytest.importorskip("transformers")

from llmtest.config import ModelSpec, load_config  # noqa: E402
from llmtest.hf_client import HFClient  # noqa: E402
from llmtest.metrics import analyse  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
TINY = "optimum-intel-internal-testing/tiny-random-gemma4-unified-it"


@pytest.fixture(scope="module")
def client():
    spec = ModelSpec(id=TINY, max_tokens=3, chat_template_kwargs={"enable_thinking": False})
    c = HFClient([spec], log=lambda *a: None)
    try:
        c._load(spec)
    except Exception as e:  # offline, etc.
        pytest.skip(f"could not load tiny model: {e}")
    return c


def test_chat_returns_completion_with_letter_candidates(client):
    msgs = [{"role": "system", "content": "Answer with a letter."},
            {"role": "user", "content": "Pick one.\nA) x\nB) y"}]
    resp, attempts = client.chat(model=TINY, messages=msgs, temperature=0, max_tokens=3, top_logprobs=5)
    assert attempts == 1
    lps = resp.choices[0].logprobs.content
    assert len(lps) == 3
    cands = {t.token for t in lps[0].top_logprobs}
    assert {"A", " A", "B", " B"} <= cands            # every option letter is scored, not just top-k
    assert resp.usage.completion_tokens == 3
    # the metrics layer can consume it
    m = analyse(resp.choices[0].message.content, lps, ["A", "B"])
    assert m["logprobs_available"] is True


def test_answer_marker_trims_reasoning(client, monkeypatch):
    spec = client.specs[TINY]
    monkeypatch.setattr(spec, "answer_marker", "<<never appears>>")
    resp, _ = client.chat(model=TINY, messages=[{"role": "user", "content": "hi"}],
                          temperature=0, max_tokens=3, top_logprobs=2)
    assert resp.choices[0].logprobs.content == []      # no final answer reached -> nothing scored
    assert resp.choices[0].message.content == ""


def test_colab_config_loads():
    cfg = load_config(ROOT / "config.colab.toml")
    assert cfg.backend == "huggingface"
    assert {m.id for m in cfg.models} >= {"google/gemma-4-12B-it", "openai/gpt-oss-20b"}


def test_duplicate_model_ids_rejected(tmp_path):
    p = tmp_path / "c.toml"
    p.write_text('[[models]]\nid = "a"\n[[models]]\nid = "a"\n')
    with pytest.raises(ValueError, match="duplicated"):
        load_config(p)
