import json
from pathlib import Path

import openai

try:  # openai>=3 ships its HTTP layer as httpx2; older versions use httpx
    import httpx2 as httpx
except ImportError:
    import httpx
import pytest

from conftest import make_completion
from llmtest import client as client_mod
from llmtest.client import DailyLimitReached, OpenRouterClient
from llmtest.config import load_config
from llmtest.questions import load_questions
from llmtest.report import build_report
from llmtest.runner import load_records, run_test

ROOT = Path(__file__).resolve().parents[1]


class FakeClient:
    """Answers every question with the correct letter; can hit a 'daily limit' after N calls."""

    def __init__(self, questions, stop_after=None, fail_ids=()):
        self.answers = {q.to_prompt(): (q.answer or "A") for q in questions}
        self.calls = 0
        self.conf_calls = 0
        self.stop_after = stop_after
        self.fail_ids = fail_ids

    def chat(self, *, model, messages, **kw):
        if messages[-1]["content"].startswith("How confident"):   # stated-confidence follow-up
            self.conf_calls += 1
            return make_completion("85", {"85": 0.7, "90": 0.2, "80": 0.1}), 1
        self.calls += 1
        if self.stop_after is not None and self.calls > self.stop_after:
            raise DailyLimitReached("Rate limit exceeded: free-models-per-day")
        prompt = messages[-1]["content"]
        if any(prompt.startswith(f) for f in self.fail_ids):
            raise openai.APIConnectionError(request=httpx.Request("POST", "https://x"))
        return make_completion(self.answers[prompt]), 1


@pytest.fixture
def setup(tmp_path):
    cfg = load_config(ROOT / "config.toml")
    qpath = ROOT / "questions" / "example.csv"
    return cfg, qpath, load_questions(qpath), tmp_path / "run1"


def test_full_run_and_report(setup):
    cfg, qpath, qs, out = setup
    s = run_test(cfg, qs, qpath, out, FakeClient(qs), "run1", log=lambda *a: None)
    n = len(cfg.models) * len(qs)
    assert s["ok"] == n and s["errors"] == 0
    recs = load_records(out / "raw.jsonl")
    assert len(recs) == n
    r = recs[0]
    assert r["provider"] == "FakeProvider" and r["cost_usd"] == pytest.approx(0.00001)
    assert r["p_answer"] == pytest.approx(0.9) and r["is_correct"] is True

    report = build_report(out).read_text()
    assert "Summary by model" in report and "gpt-oss-120b" in report and "100.0%" in report
    assert (out / "summary.csv").read_text().count("\n") == n + 1


def test_stated_confidence_is_asked_and_reported(setup):
    cfg, qpath, qs, out = setup
    fake = FakeClient(qs)
    run_test(cfg, qs, qpath, out, fake, "run1", log=lambda *a: None)
    n = len(cfg.models) * len(qs)
    assert fake.conf_calls == n
    recs = load_records(out / "raw.jsonl")
    assert all(r["stated_conf"] == pytest.approx(0.85) and r["stated_conf_raw"] == "85" for r in recs)
    report = build_report(out).read_text()
    assert "Stated vs token confidence" in report and "says 0.85" in report
    assert "stated_conf" in (out / "summary.csv").read_text().splitlines()[0]


def test_stated_confidence_can_be_turned_off(setup):
    cfg, qpath, qs, out = setup
    cfg.ask_confidence = False
    fake = FakeClient(qs)
    run_test(cfg, qs, qpath, out, fake, "run1", log=lambda *a: None)
    assert fake.conf_calls == 0
    assert "Stated vs token confidence" not in build_report(out).read_text()


def test_resume_after_daily_limit(setup):
    cfg, qpath, qs, out = setup
    s1 = run_test(cfg, qs, qpath, out, FakeClient(qs, stop_after=7), "run1", log=lambda *a: None)
    assert s1["ok"] == 7 and s1["stopped_reason"] == "daily free-model limit reached"

    fake = FakeClient(qs)
    s2 = run_test(cfg, qs, qpath, out, fake, "run1", log=lambda *a: None)
    n = len(cfg.models) * len(qs)
    assert s2["skipped_already_done"] == 7 and fake.calls == n - 7
    keys = [(r["model_id"], r["question_id"]) for r in load_records(out / "raw.jsonl")]
    assert len(keys) == len(set(keys)) == n
    meta = json.loads((out / "run_meta.json").read_text())
    assert len(meta["sessions"]) == 2


def test_errors_are_recorded_then_retried_on_resume(setup):
    cfg, qpath, qs, out = setup
    s1 = run_test(cfg, qs, qpath, out, FakeClient(qs, fail_ids=("What is the capital",)), "run1",
                  log=lambda *a: None)
    assert s1["errors"] == len(cfg.models)
    assert "## Errors" in build_report(out).read_text()

    fake = FakeClient(qs)
    run_test(cfg, qs, qpath, out, fake, "run1", log=lambda *a: None)
    assert fake.calls == len(cfg.models)          # only the failed ones re-asked
    assert "## Errors" not in build_report(out).read_text()


def test_changed_questions_file_is_refused(setup, tmp_path):
    cfg, qpath, qs, out = setup
    copy = tmp_path / "q.csv"
    copy.write_text(qpath.read_text())
    run_test(cfg, qs, copy, out, FakeClient(qs, stop_after=1), "run1", log=lambda *a: None)
    copy.write_text(qpath.read_text() + "q11,x,Extra?,a,b,,,A\n")
    with pytest.raises(SystemExit):
        run_test(cfg, load_questions(copy), copy, out, FakeClient(qs), "run1", log=lambda *a: None)


def _rate_limit(msg):
    req = httpx.Request("POST", "https://openrouter.ai/api/v1/chat/completions")
    return openai.RateLimitError(msg, response=httpx.Response(429, request=req, headers={"retry-after": "1"}), body=None)


def test_client_retries_then_succeeds(monkeypatch):
    sleeps = []
    monkeypatch.setattr(client_mod.time, "sleep", lambda s: sleeps.append(s))
    c = OpenRouterClient(api_key="x", base_url="https://openrouter.ai/api/v1", requests_per_minute=0,
                         max_retries=3, log=lambda *a: None)
    outcomes = [_rate_limit("slow down"), _rate_limit("slow down"), make_completion("B")]

    def fake_create(**kw):
        assert kw["logprobs"] is True and kw["extra_body"]["provider"]["require_parameters"] is True
        o = outcomes.pop(0)
        if isinstance(o, Exception):
            raise o
        return o

    monkeypatch.setattr(c.client.chat.completions, "create", fake_create)
    resp, attempts = c.chat(model="m", messages=[], temperature=0, max_tokens=5, top_logprobs=5)
    assert attempts == 3 and sleeps == [1.0, 1.0]


def test_client_daily_limit_not_retried(monkeypatch):
    monkeypatch.setattr(client_mod.time, "sleep", lambda s: None)
    c = OpenRouterClient(api_key="x", base_url="https://openrouter.ai/api/v1", requests_per_minute=0,
                         log=lambda *a: None)

    def fake_create(**kw):
        raise _rate_limit("Rate limit exceeded: free-models-per-day")

    monkeypatch.setattr(c.client.chat.completions, "create", fake_create)
    with pytest.raises(DailyLimitReached):
        c.chat(model="m", messages=[], temperature=0, max_tokens=5, top_logprobs=5)


# ---------- "not sure" option ----------

from llmtest.questions import apply_not_sure  # noqa: E402

VET = ROOT / "questions" / "veterinary_sample_15.csv"


def test_hide_not_sure_removes_option_and_drops_e_answers():
    qs = load_questions(VET)
    kept, dropped = apply_not_sure(qs, "E", offer=False)
    assert dropped == ["VET-003", "VET-008", "VET-013"]
    assert len(kept) == 12 and all(q.letters == ["A", "B", "C", "D"] for q in kept)
    assert "E)" not in kept[0].to_prompt()
    assert qs[0].letters == ["A", "B", "C", "D", "E"]          # originals untouched
    same, none = apply_not_sure(qs, "E", offer=True)
    assert same is qs and none == []


def test_run_with_not_sure_offered_and_hidden(tmp_path):
    cfg = load_config(ROOT / "config.toml")
    cfg.models = cfg.models[:1]
    qs = load_questions(VET)

    cfg.offer_not_sure = True
    s = run_test(cfg, qs, VET, tmp_path / "offer", FakeClient(qs), "offer", log=lambda *a: None)
    recs = load_records(tmp_path / "offer" / "raw.jsonl")
    assert s["ok"] == 15 and all(r["not_sure_offered"] for r in recs)
    assert sorted(r["question_id"] for r in recs if r["abstained"]) == ["VET-003", "VET-008", "VET-013"]
    rep = build_report(tmp_path / "offer").read_text()
    assert "offered to the model" in rep and "Not sure chosen" in rep and "20.0%" in rep
    assert "E (not sure)" in rep

    cfg.offer_not_sure = False
    kept, dropped = apply_not_sure(qs, "E", offer=False)
    s = run_test(cfg, kept, VET, tmp_path / "hide", FakeClient(kept), "hide",
                 log=lambda *a: None, dropped=dropped)
    recs = load_records(tmp_path / "hide" / "raw.jsonl")
    assert s["ok"] == 12 and not any(r["not_sure_offered"] for r in recs)
    assert all("E" not in r["options"] for r in recs)
    rep = build_report(tmp_path / "hide").read_text()
    assert "hidden from the model" in rep and "VET-003" in rep and "Not sure chosen" not in rep

    # resuming the 'hide' run with the option offered is refused
    cfg.offer_not_sure = True
    with pytest.raises(SystemExit, match="hidden"):
        run_test(cfg, qs, VET, tmp_path / "hide", FakeClient(qs), "hide", log=lambda *a: None)
