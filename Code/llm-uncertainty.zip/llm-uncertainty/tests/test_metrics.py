import math

import pytest

from llmtest.metrics import (analyse, auroc, brier, entropy_bits, expected_calibration_error,
                             letter_from_text, option_distribution, probit, token_letter)

L = ["A", "B", "C", "D"]


@pytest.mark.parametrize("tok,expected", [
    ("B", "B"), (" B", "B"), ("B)", "B"), ("**B", "B"), ("(C)", "C"), ("D.", "D"),
    ("a", None), ("E", None), ("Bob", None), ("", None),
])
def test_token_letter(tok, expected):
    assert token_letter(tok, L) == expected


def test_letter_from_text():
    assert letter_from_text("The answer is C.", L) == "C"
    assert letter_from_text("no idea", L) is None


def test_option_distribution_merges_variants_and_normalises():
    entry = {"token": "B", "logprob": math.log(0.6), "top_logprobs": [
        {"token": "B", "logprob": math.log(0.6)},
        {"token": " B", "logprob": math.log(0.1)},
        {"token": "A", "logprob": math.log(0.2)},
        {"token": "Hmm", "logprob": math.log(0.1)},
    ]}
    mass, total, norm = option_distribution(entry, L)
    assert mass["B"] == pytest.approx(0.7)
    assert total == pytest.approx(0.9)
    assert norm["B"] == pytest.approx(0.7 / 0.9)
    assert sum(norm.values()) == pytest.approx(1.0)


def test_entropy_and_probit():
    assert entropy_bits({"A": 1.0, "B": 0.0}) == 0
    assert entropy_bits({k: 0.25 for k in L}) == pytest.approx(2.0)
    assert probit(0.5) == pytest.approx(0.0)
    assert probit(0.975) == pytest.approx(1.96, abs=1e-3)
    assert math.isfinite(probit(1.0))


def test_analyse_finds_answer_after_preamble():
    lps = [{"token": "Answer", "logprob": -0.1, "top_logprobs": []},
           {"token": ":", "logprob": -0.1, "top_logprobs": []},
           {"token": " C", "logprob": math.log(0.8), "top_logprobs": [
               {"token": " C", "logprob": math.log(0.8)}, {"token": " A", "logprob": math.log(0.2)}]}]
    m = analyse("Answer: C", lps, L)
    assert m["answer"] == "C"
    assert m["p_answer"] == pytest.approx(0.8)
    assert m["margin"] == pytest.approx(0.6)


def test_analyse_without_logprobs_falls_back_to_text():
    m = analyse("B", [], L)
    assert m["answer"] == "B" and m["p_answer"] is None and not m["logprobs_available"]


def test_aggregate_metrics():
    assert brier({"A": 1.0, "B": 0.0}, "A") == 0
    assert brier({"A": 0.0, "B": 1.0}, "A") == 2
    assert auroc([0.9, 0.8, 0.3], [True, True, False]) == 1.0
    assert auroc([0.9, 0.9], [True, False]) == 0.5
    assert expected_calibration_error([1.0, 1.0], [True, True]) == 0
    assert expected_calibration_error([0.9, 0.9], [False, False]) == pytest.approx(0.9)


def test_loader_accepts_option_x_columns_and_keeps_metadata(tmp_path):
    from llmtest.questions import load_questions
    p = tmp_path / "q.csv"
    p.write_text("question_id,species,question,option_a,option_b,option_c,correct_option\n"
                 "V1,dog,Which?,x,y,z,c\n", encoding="utf-8")
    q = load_questions(p)[0]
    assert q.id == "V1" and q.letters == ["A", "B", "C"] and q.answer == "C"
    assert q.meta == {"species": "dog"}


def test_parse_stated_confidence():
    from llmtest.metrics import parse_stated_confidence as f
    assert f("85") == 0.85 and f("85%") == 0.85 and f("I'd say 70.") == 0.7
    assert f("0.9") == pytest.approx(0.9) and f("150") == 1.0 and f("not sure") is None and f(None) is None


def test_spearman():
    from llmtest.metrics import spearman
    assert spearman([1, 2, 3, 4], [10, 20, 30, 40]) == pytest.approx(1.0)
    assert spearman([1, 2, 3, 4], [4, 3, 2, 1]) == pytest.approx(-1.0)
    assert spearman([1, 2], [1, 2]) is None
