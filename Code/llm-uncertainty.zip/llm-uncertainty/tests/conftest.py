import math
import sys
from pathlib import Path

import pytest
from openai.types.chat import ChatCompletion

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def make_completion(content="B", dist=None, provider="FakeProvider", with_logprobs=True, cost=0.00001):
    """Build a real ChatCompletion object like OpenRouter returns.

    dist: {token: probability} for the first token position, e.g. {"B": 0.9, "A": 0.06, " B": 0.02}
    """
    dist = dist or {content: 0.9, "A": 0.05, "C": 0.03, "D": 0.02}
    top = [{"token": t, "logprob": math.log(p), "bytes": None} for t, p in dist.items()]
    chosen = next(t for t in top if t["token"] == content)
    logprobs = {"content": [{**chosen, "top_logprobs": top}]} if with_logprobs else None
    return ChatCompletion.model_validate({
        "id": "gen-1", "object": "chat.completion", "created": 0, "model": "fake/model",
        "provider": provider,
        "choices": [{"index": 0, "finish_reason": "stop", "logprobs": logprobs,
                     "message": {"role": "assistant", "content": content}}],
        "usage": {"prompt_tokens": 50, "completion_tokens": 1, "total_tokens": 51, "cost": cost},
    })


@pytest.fixture
def completion():
    return make_completion
