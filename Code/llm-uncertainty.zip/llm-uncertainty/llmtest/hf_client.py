"""Run Hugging Face open-weight models locally (e.g. on a free Colab GPU) instead of calling an API.

Exposes the same `chat()` interface as OpenRouterClient and returns an OpenAI-style ChatCompletion,
so the runner, metrics and report work unchanged. Costs nothing: the model runs on your own GPU.

Because we have the model's full output distribution, each answer position includes the top-k tokens
*plus* every option-letter token ("A", " A", "B", ...), so option probabilities are exact rather than
limited to whatever made the top-k.
"""
from __future__ import annotations

import gc
import re
import string
import time

from .client import ModelUnavailable
from .config import ModelSpec


def _pick_dtype(torch, spec_dtype: str):
    if spec_dtype == "auto":
        return "auto"
    if spec_dtype in ("float16", "bfloat16", "float32"):
        return getattr(torch, spec_dtype)
    # "best": bf16 on Ampere or newer (A100, L4); float32 on older GPUs like the T4, where
    # float16 can overflow for some models and bf16 has no hardware support.
    if torch.cuda.is_available() and torch.cuda.get_device_capability() >= (8, 0):
        return torch.bfloat16
    return torch.float32


class HFClient:
    def __init__(self, models: list[ModelSpec], log=print):
        self.specs = {m.id: m for m in models}
        self.log = log
        self.current: str | None = None
        self.model = None
        self.tok = None
        self.letter_ids: dict[int, str] = {}
        self.device_name = "cpu"

    # ---------- loading ----------

    def _unload(self):
        if self.model is None:
            return
        import torch
        self.model = None
        self.tok = None
        self.current = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def _load(self, spec: ModelSpec):
        import torch
        import transformers
        from transformers import AutoTokenizer

        self._unload()
        cuda = torch.cuda.is_available()
        self.device_name = torch.cuda.get_device_name(0) if cuda else "cpu"
        dtype = _pick_dtype(torch, spec.dtype)
        kwargs: dict = {"dtype": dtype}
        if cuda:
            kwargs["device_map"] = "auto"
        if spec.quantization in ("4bit", "8bit"):
            if not cuda:
                raise ModelUnavailable(f"{spec.quantization} quantization needs a GPU (bitsandbytes)")
            from transformers import BitsAndBytesConfig
            compute = dtype if dtype not in ("auto",) else torch.float16
            kwargs["quantization_config"] = (
                BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                   bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=compute)
                if spec.quantization == "4bit" else BitsAndBytesConfig(load_in_8bit=True))
        elif spec.quantization not in (None, "", "none"):
            raise ModelUnavailable(f"unknown quantization {spec.quantization!r} (use 4bit, 8bit or none)")

        cls = getattr(transformers, spec.auto_class or "AutoModelForCausalLM")
        self.log(f"  loading {spec.id} on {self.device_name} "
                 f"(dtype={dtype}, quantization={spec.quantization or 'none'}) — first time downloads the weights")
        t0 = time.monotonic()
        try:
            self.tok = AutoTokenizer.from_pretrained(spec.id)
            self.model = cls.from_pretrained(spec.id, **kwargs)
            self.model.eval()
        except Exception as e:
            self._unload()
            hint = ""
            if "out of memory" in str(e).lower():
                hint = " — not enough GPU memory; try quantization = \"4bit\" or a smaller model"
            raise ModelUnavailable(f"could not load {spec.id}: {type(e).__name__}: {str(e)[:300]}{hint}") from e
        self.current = spec.id
        self.log(f"  loaded in {time.monotonic() - t0:.0f}s")

        # every single-token spelling of a capital letter, so option probabilities are exact
        self.letter_ids = {}
        for L in string.ascii_uppercase:
            for variant in (L, " " + L):
                ids = self.tok.encode(variant, add_special_tokens=False)
                if len(ids) == 1:
                    self.letter_ids[ids[0]] = variant

    # ---------- inference ----------

    def chat(self, *, model: str, messages: list[dict], temperature: float, max_tokens: int,
             top_logprobs: int, reasoning: dict | None = None):
        import torch
        from openai.types.chat import ChatCompletion

        spec = self.specs[model]
        if self.current != model:
            self._load(spec)
        tok, mdl = self.tok, self.model

        prompt = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True,
                                         **(spec.chat_template_kwargs or {}))
        if spec.assistant_prefill:
            prompt += spec.assistant_prefill
        enc = tok(prompt, return_tensors="pt", add_special_tokens=False).to(mdl.device)
        n_in = enc["input_ids"].shape[-1]

        gen = {"max_new_tokens": max_tokens, "return_dict_in_generate": True, "output_logits": True,
               "pad_token_id": tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id}
        if temperature and temperature > 0:
            gen.update(do_sample=True, temperature=temperature)
        else:
            gen.update(do_sample=False, temperature=None, top_p=None, top_k=None)

        t0 = time.monotonic()
        with torch.inference_mode():
            out = mdl.generate(**enc, **gen)
        seq = out.sequences[0, n_in:].tolist()
        logits = out.logits  # raw (unwarped) logits, one tensor per generated token

        entries = []
        for i, tid in enumerate(seq):
            lp = torch.log_softmax(logits[i][0].float(), dim=-1)
            if torch.isnan(lp).any():
                raise RuntimeError(f"model produced NaN logits — set dtype = \"float32\" for {spec.id}")
            k = min(max(top_logprobs, 1), lp.shape[-1])
            vals, idx = lp.topk(k)
            cand = dict(zip(idx.tolist(), vals.tolist()))
            for lid in self.letter_ids:
                cand.setdefault(lid, lp[lid].item())
            entries.append({
                "token": tok.decode([tid]),
                "logprob": lp[tid].item(),
                "bytes": None,
                "top_logprobs": [{"token": tok.decode([c]), "logprob": v, "bytes": None}
                                 for c, v in sorted(cand.items(), key=lambda x: -x[1])],
            })

        # keep only the final answer (e.g. skip gpt-oss's analysis channel)
        start = 0
        finish = "length" if len(seq) >= max_tokens else "stop"
        if spec.answer_marker:
            pieces, start = "", None
            for i, tid in enumerate(seq):
                pieces += tok.decode([tid])
                if spec.answer_marker in pieces:
                    start = i + 1
                    break
            if start is None:  # never reached a final answer (usually ran out of max_tokens)
                start = len(seq)
        answer_ids = seq[start:]
        content = tok.decode(answer_ids, skip_special_tokens=True).strip()
        content = re.sub(r"^thought\s*\n", "", content)

        resp = ChatCompletion.model_validate({
            "id": f"local-{int(time.time() * 1000)}", "object": "chat.completion",
            "created": int(time.time()), "model": spec.id,
            "provider": f"local ({self.device_name})",
            "choices": [{"index": 0, "finish_reason": finish,
                         "message": {"role": "assistant", "content": content},
                         "logprobs": {"content": entries[start:]}}],
            "usage": {"prompt_tokens": n_in, "completion_tokens": len(seq),
                      "total_tokens": n_in + len(seq), "cost": 0.0},
        })
        return resp, 1
