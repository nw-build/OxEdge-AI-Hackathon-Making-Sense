"""Run every (model x question x repeat) once, append results to raw.jsonl, resume safely."""
from __future__ import annotations

import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import openai

from .client import DailyLimitReached, ModelUnavailable
from .config import Config, ModelSpec
from .metrics import analyse, parse_stated_confidence
from .questions import Question, file_sha256


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def git_commit() -> str | None:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"], capture_output=True,
                              text=True, check=True).stdout.strip() or None
    except Exception:
        return None


def load_records(raw_path: Path) -> list[dict]:
    if not raw_path.exists():
        return []
    out = []
    with raw_path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue  # a half-written last line from an interrupted run
    return out


def _key(rec) -> tuple:
    return (rec["model_id"], rec["question_id"], rec["repeat"])


def _attr(obj, name, default=None):
    if obj is None:
        return default
    val = getattr(obj, name, None)
    if val is None:
        val = (getattr(obj, "model_extra", None) or {}).get(name, default)
    return val


def build_record(run_name: str, model: ModelSpec, q: Question, repeat: int, resp, attempts: int,
                 latency: float, save_raw: bool, not_sure: str | None = None) -> dict:
    """not_sure: letter of the 'not sure' option if it was offered to the model, else None."""
    choice = resp.choices[0]
    content = choice.message.content or ""
    lp_obj = choice.logprobs
    content_lps = list(lp_obj.content) if lp_obj is not None and lp_obj.content else []
    m = analyse(content, content_lps, q.letters)
    usage = getattr(resp, "usage", None)

    rec = {
        "run": run_name,
        "timestamp": _now(),
        "status": "ok",
        "model_id": model.id,
        "model_label": model.label,
        "served_model": getattr(resp, "model", None),
        "provider": _attr(resp, "provider"),
        "question_id": q.id,
        "category": q.category,
        "meta": q.meta,
        "repeat": repeat,
        "question": q.question,
        "options": q.options,
        "response_text": content,
        "answer": m["answer"],
        "correct_answer": q.answer,
        "is_correct": (m["answer"] == q.answer) if (q.answer and m["answer"]) else (False if q.answer else None),
        "logprobs_available": m["logprobs_available"],
        "p_answer": m["p_answer"],
        "p_token": m["p_token"],
        "probit": m["probit"],
        "entropy_bits": m["entropy_bits"],
        "norm_entropy": m["norm_entropy"],
        "margin": m["margin"],
        "option_probs": m["option_probs"],
        "option_mass": m["option_mass"],
        "not_sure_offered": bool(not_sure and not_sure in q.options),
        "abstained": bool(not_sure and m["answer"] == not_sure),
        "p_not_sure": m["option_probs"].get(not_sure) if not_sure else None,
        "finish_reason": choice.finish_reason,
        "prompt_tokens": _attr(usage, "prompt_tokens"),
        "completion_tokens": _attr(usage, "completion_tokens"),
        "cost_usd": _attr(usage, "cost"),
        "latency_s": round(latency, 3),
        "attempts": attempts,
        "error": None,
        "stated_conf": None,
        "stated_conf_raw": None,
        "stated_conf_error": None,
    }
    if save_raw:
        rec["raw_response"] = resp.model_dump(exclude_none=True)
    return rec


def ask_stated_confidence(cfg: Config, client, model: ModelSpec, messages: list[dict], rec: dict,
                          temperature: float) -> None:
    """Second call: show the model its own answer and ask how confident it is (0-100)."""
    if not cfg.ask_confidence or not rec.get("answer"):
        return
    follow_up = messages + [
        {"role": "assistant", "content": rec["answer"]},
        {"role": "user", "content": cfg.confidence_prompt.format(answer=rec["answer"])},
    ]
    try:
        resp, _ = client.chat(model=model.id, messages=follow_up, temperature=temperature,
                              max_tokens=max(model.max_tokens, cfg.confidence_max_tokens),
                              top_logprobs=cfg.top_logprobs, reasoning=model.reasoning)
        text = (resp.choices[0].message.content or "").strip()
        rec["stated_conf_raw"] = text
        rec["stated_conf"] = parse_stated_confidence(text)
    except (DailyLimitReached, ModelUnavailable):
        raise
    except Exception as e:  # keep the answer even if the follow-up fails
        rec["stated_conf_error"] = f"{type(e).__name__}: {str(e)[:300]}"


def error_record(run_name, model: ModelSpec, q: Question, repeat: int, exc: Exception) -> dict:
    return {
        "run": run_name, "timestamp": _now(), "status": "error",
        "model_id": model.id, "model_label": model.label,
        "question_id": q.id, "category": q.category, "meta": q.meta, "repeat": repeat,
        "question": q.question, "options": q.options, "correct_answer": q.answer,
        "error": f"{type(exc).__name__}: {str(exc)[:500]}",
    }


def _not_sure_settings(cfg: Config, dropped) -> dict:
    return {"option": cfg.not_sure_option or None, "offered": cfg.offer_not_sure,
            "dropped_questions": list(dropped)}


def write_meta(out_dir: Path, cfg: Config, questions_path: Path, questions: list[Question],
               run_name: str, session: dict, dropped=()):
    meta_path = out_dir / "run_meta.json"
    sha = file_sha256(questions_path)
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        if meta.get("questions_sha256") != sha:
            raise SystemExit(
                f"{questions_path} has changed since this run started. "
                f"Use a new --name, or delete {out_dir} to start over.")
    else:
        meta = {
            "run_name": run_name,
            "created": _now(),
            "questions_file": str(questions_path),
            "questions_sha256": sha,
            "n_questions": len(questions),
            "git_commit": git_commit(),
            "config": cfg.raw,
            "not_sure": _not_sure_settings(cfg, dropped),
            "sessions": [],
        }
    meta["sessions"].append(session)
    meta_path.write_text(json.dumps(meta, indent=2))


def run_test(cfg: Config, questions: list[Question], questions_path: Path, out_dir: Path,
             client, run_name: str, log=print, dropped=()) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    meta_path = out_dir / "run_meta.json"
    if meta_path.exists():
        old = json.loads(meta_path.read_text())
        if old.get("questions_sha256") != file_sha256(questions_path):
            raise SystemExit(f"{questions_path} has changed since run '{run_name}' started. "
                             f"Use a new --name, or delete {out_dir} to start over.")
        old_offer = (old.get("not_sure") or {}).get("offered", True)
        if old_offer != cfg.offer_not_sure:
            raise SystemExit(f"Run '{run_name}' was started with the not-sure option "
                             f"{'offered' if old_offer else 'hidden'}. Use a new --name for the other setting.")
    not_sure = cfg.not_sure_option if (cfg.offer_not_sure and cfg.not_sure_option) else None
    raw_path = out_dir / "raw.jsonl"
    done ={_key(r) for r in load_records(raw_path) if r.get("status") == "ok"}

    session = {"started": _now(), "calls": 0, "ok": 0, "errors": 0,
               "skipped_already_done": 0, "stopped_reason": None, "git_commit": git_commit()}
    total = len(cfg.models) * len(questions) * cfg.repeats
    n = 0

    with raw_path.open("a", encoding="utf-8") as f:
        def save(rec):
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f.flush()

        try:
            for model in cfg.models:
                log(f"\n== {model.label} ({model.id})")
                temperature = cfg.temperature if model.temperature is None else model.temperature
                skip_model = False
                for q in questions:
                    for r in range(cfg.repeats):
                        n += 1
                        if (model.id, q.id, r) in done:
                            session["skipped_already_done"] += 1
                            continue
                        if skip_model:
                            continue
                        messages = [{"role": "system", "content": cfg.system_prompt},
                                    {"role": "user", "content": q.to_prompt()}]
                        t0 = time.monotonic()
                        session["calls"] += 1
                        try:
                            resp, attempts = client.chat(
                                model=model.id, messages=messages, temperature=temperature,
                                max_tokens=model.max_tokens, top_logprobs=cfg.top_logprobs,
                                reasoning=model.reasoning)
                            rec = build_record(run_name, model, q, r, resp, attempts,
                                               time.monotonic() - t0, cfg.save_raw_response, not_sure)
                            ask_stated_confidence(cfg, client, model, messages, rec, temperature)
                            session["ok"] += 1
                            p = rec["p_answer"]
                            mark = (" (not sure)" if rec["abstained"] else "" if rec["is_correct"] is None
                                    else " ✓" if rec["is_correct"] else " ✗")
                            ptxt = (f"p={p:.3f}" if p is not None else
                                    "no answer letter found" if rec["logprobs_available"] else "no logprobs")
                            sc = rec.get("stated_conf")
                            stxt = (f"  says {round(sc * 100)}%" if sc is not None else
                                    f"  says {rec['stated_conf_raw']!r}" if rec.get("stated_conf_raw") else "")
                            log(f"  [{n}/{total}] {q.id} r{r}: {rec['answer']}{mark}  {ptxt}{stxt}")
                        except DailyLimitReached:
                            raise
                        except ModelUnavailable as e:
                            rec = error_record(run_name, model, q, r, e)
                            session["errors"] += 1
                            log(f"  ERROR {rec['error'][:300]}\n  -> skipping this model")
                            skip_model = True
                        except (openai.AuthenticationError, openai.PermissionDeniedError) as e:
                            session["stopped_reason"] = f"auth error: {e}"
                            raise SystemExit(f"Authentication failed — check your API key. ({e})")
                        except openai.APIStatusError as e:
                            if e.status_code == 402:
                                session["stopped_reason"] = "402 payment required"
                                raise SystemExit("OpenRouter returned 402 (out of credits / negative balance).")
                            rec = error_record(run_name, model, q, r, e)
                            session["errors"] += 1
                            log(f"  [{n}/{total}] {q.id} r{r}: ERROR {rec['error'][:160]}")
                            if e.status_code == 404:
                                log("  -> model unavailable or no provider supports logprobs; skipping this model")
                                skip_model = True
                        except Exception as e:  # retries exhausted, network, parsing...
                            rec = error_record(run_name, model, q, r, e)
                            session["errors"] += 1
                            log(f"  [{n}/{total}] {q.id} r{r}: ERROR {rec['error'][:160]}")
                        save(rec)
        except DailyLimitReached as e:
            session["stopped_reason"] = "daily free-model limit reached"
            log(f"\nStopped: daily request limit reached ({e}).\n"
                f"Everything so far is saved. Re-run the same command with --name {run_name} to resume.")
        except KeyboardInterrupt:
            session["stopped_reason"] = "interrupted"
            log(f"\nInterrupted. Re-run with --name {run_name} to resume.")
        finally:
            session["finished"] = _now()
            write_meta(out_dir, cfg, questions_path, questions, run_name, session, dropped)

    return session
