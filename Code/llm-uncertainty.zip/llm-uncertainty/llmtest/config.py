"""Load and validate config.toml."""
from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_CONFIDENCE_PROMPT = (
    "How confident are you that your answer ({answer}) is correct? "
    "Reply with only a number from 0 to 100, where 0 means certainly wrong and 100 means certainly correct."
)

DEFAULT_SYSTEM_PROMPT = (
    "You will be given a multiple-choice question. "
    "Reply with only the letter of the correct option and nothing else."
)


@dataclass
class ModelSpec:
    id: str
    label: str = ""
    max_tokens: int = 16
    temperature: float | None = None          # overrides [run].temperature if set
    reasoning: dict[str, Any] | None = None   # passed straight to OpenRouter's `reasoning` field
    # --- huggingface backend only ---
    quantization: str | None = None           # "4bit", "8bit" or none
    dtype: str = "best"                       # best | auto | bfloat16 | float16 | float32
    chat_template_kwargs: dict[str, Any] | None = None   # e.g. {enable_thinking = false}
    answer_marker: str | None = None          # read the answer only after this text (e.g. gpt-oss final channel)
    assistant_prefill: str | None = None      # text appended after the generation prompt
    auto_class: str | None = None             # transformers class, default AutoModelForCausalLM

    def __post_init__(self):
        if not self.label:
            self.label = self.id


@dataclass
class Config:
    models: list[ModelSpec]
    backend: str = "openrouter"               # openrouter | huggingface
    temperature: float = 0.0
    top_logprobs: int = 10
    repeats: int = 1
    system_prompt: str = DEFAULT_SYSTEM_PROMPT
    save_raw_response: bool = True
    not_sure_option: str = "E"       # letter of the "not sure / insufficient information" option
    offer_not_sure: bool = True      # show that option to the model, or remove it
    # stated (verbalised) confidence: after the answer, ask the model how sure it is (0-100)
    ask_confidence: bool = True
    confidence_prompt: str = DEFAULT_CONFIDENCE_PROMPT
    confidence_max_tokens: int = 8
    base_url: str = "https://openrouter.ai/api/v1"
    api_key_env: str = "OPENROUTER_API_KEY"
    requests_per_minute: float = 18
    max_retries: int = 6
    timeout_seconds: float = 120
    require_parameters: bool = True
    raw: dict[str, Any] = field(default_factory=dict)


def load_config(path: str | Path) -> Config:
    path = Path(path)
    with path.open("rb") as f:
        data = tomllib.load(f)

    models_data = data.get("models") or []
    if not models_data:
        raise ValueError(f"{path}: add at least one [[models]] entry")
    models = []
    for m in models_data:
        if "id" not in m:
            raise ValueError(f"{path}: every [[models]] entry needs an `id`")
        models.append(ModelSpec(**m))
    ids = [m.id for m in models]
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    if dupes:
        raise ValueError(f"{path}: each model id may appear once (duplicated: {', '.join(dupes)}). "
                         "To compare settings for one model, use separate config files and run names.")

    run = data.get("run", {})
    api = data.get("api", {})
    backend = data.get("backend", {}).get("type", "openrouter")
    if backend not in ("openrouter", "huggingface"):
        raise ValueError(f"{path}: [backend] type must be 'openrouter' or 'huggingface'")
    cfg = Config(
        models=models,
        backend=backend,
        temperature=run.get("temperature", 0.0),
        top_logprobs=run.get("top_logprobs", 10),
        repeats=run.get("repeats", 1),
        system_prompt=run.get("system_prompt", DEFAULT_SYSTEM_PROMPT),
        save_raw_response=run.get("save_raw_response", True),
        not_sure_option=str(run.get("not_sure_option", "E") or "").strip().upper(),
        offer_not_sure=bool(run.get("offer_not_sure", True)),
        ask_confidence=bool(run.get("ask_confidence", True)),
        confidence_prompt=run.get("confidence_prompt", DEFAULT_CONFIDENCE_PROMPT),
        confidence_max_tokens=int(run.get("confidence_max_tokens", 8)),
        base_url=api.get("base_url", "https://openrouter.ai/api/v1"),
        api_key_env=api.get("api_key_env", "OPENROUTER_API_KEY"),
        requests_per_minute=api.get("requests_per_minute", 18),
        max_retries=api.get("max_retries", 6),
        timeout_seconds=api.get("timeout_seconds", 120),
        require_parameters=api.get("require_parameters", True),
        raw=data,
    )
    if not 0 <= cfg.top_logprobs <= 20:
        raise ValueError("top_logprobs must be between 0 and 20")
    if cfg.repeats < 1:
        raise ValueError("repeats must be >= 1")
    return cfg
