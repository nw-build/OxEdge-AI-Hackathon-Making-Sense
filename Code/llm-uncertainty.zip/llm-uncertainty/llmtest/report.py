"""Build summary.csv and report.md from a run folder."""
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

from .metrics import auroc, brier, expected_calibration_error, spearman
from .runner import load_records

CSV_FIELDS = [
    "model_label", "model_id", "provider", "question_id", "category", "repeat", "answer",
    "correct_answer", "is_correct", "p_answer", "stated_conf", "stated_conf_raw", "probit", "entropy_bits", "norm_entropy",
    "margin", "option_probs", "option_mass", "not_sure_offered", "abstained", "p_not_sure", "p_token", "logprobs_available", "response_text",
    "finish_reason", "prompt_tokens", "completion_tokens", "cost_usd", "latency_s",
    "attempts", "status", "error", "timestamp",
]


def _fmt(x, nd=3, pct=False):
    if x is None:
        return "–"
    if pct:
        return f"{100 * x:.1f}%"
    return f"{x:.{nd}f}"


def _avg(xs):
    xs = [x for x in xs if x is not None]
    return mean(xs) if xs else None


def latest_records(raw_path: Path) -> list[dict]:
    """One record per (model, question, repeat): the latest success, else the latest error."""
    best: dict[tuple, dict] = {}
    for r in load_records(raw_path):
        k = (r["model_id"], r["question_id"], r["repeat"])
        prev = best.get(k)
        if prev is None or r["status"] == "ok" or prev["status"] != "ok":
            best[k] = r
    return list(best.values())


def model_summary(recs: list[dict]) -> dict:
    ok = [r for r in recs if r["status"] == "ok"]
    with_lp = [r for r in ok if r.get("p_answer") is not None]
    graded = [r for r in ok if r.get("is_correct") is not None]
    graded_lp = [r for r in with_lp if r.get("is_correct") is not None]
    conf = [r["p_answer"] for r in graded_lp]
    corr = [r["is_correct"] for r in graded_lp]

    agreement = None
    by_q = defaultdict(list)
    for r in ok:
        by_q[r["question_id"]].append(r.get("answer"))
    multi = [v for v in by_q.values() if len(v) > 1]
    if multi:
        agreement = mean(Counter(v).most_common(1)[0][1] / len(v) for v in multi)

    st = [r for r in graded if r.get("stated_conf") is not None]
    st_lp = [r for r in st if r.get("p_answer") is not None]
    stated = {
        "stated_asked": any(r.get("stated_conf") is not None or r.get("stated_conf_raw") for r in ok),
        "stated_rate": (len([r for r in ok if r.get("stated_conf") is not None]) / len(ok)) if ok else None,
        "mean_stated": _avg(r.get("stated_conf") for r in ok),
        "stated_right": _avg(r["stated_conf"] for r in st if r["is_correct"]),
        "stated_wrong": _avg(r["stated_conf"] for r in st if not r["is_correct"]),
        "ece_stated": expected_calibration_error([r["stated_conf"] for r in st], [r["is_correct"] for r in st]),
        "auroc_stated": auroc([r["stated_conf"] for r in st], [r["is_correct"] for r in st]),
        "rho_token_stated": spearman([r["p_answer"] for r in st_lp], [r["stated_conf"] for r in st_lp]),
        "distinct_stated": len({round(r["stated_conf"] * 100) for r in ok if r.get("stated_conf") is not None}),
    }

    costs = [r.get("cost_usd") for r in ok if r.get("cost_usd") is not None]
    offered = [r for r in ok if r.get("not_sure_offered")]
    answered = [r for r in graded if not r.get("abstained")]
    return {
        "not_sure_offered": bool(offered),
        "not_sure_rate": (sum(bool(r.get("abstained")) for r in offered) / len(offered)) if offered else None,
        "mean_p_not_sure": _avg(r.get("p_not_sure") for r in offered),
        "acc_answered": (sum(r["is_correct"] for r in answered) / len(answered)) if answered else None,
        "calls_ok": len(ok),
        "errors": len(recs) - len(ok),
        "logprob_rate": len(with_lp) / len(ok) if ok else None,
        "accuracy": (sum(r["is_correct"] for r in graded) / len(graded)) if graded else None,
        "mean_conf": _avg(r["p_answer"] for r in with_lp),
        "conf_right": _avg(r["p_answer"] for r in graded_lp if r["is_correct"]),
        "conf_wrong": _avg(r["p_answer"] for r in graded_lp if not r["is_correct"]),
        "mean_entropy": _avg(r.get("entropy_bits") for r in with_lp),
        "mean_probit": _avg(r.get("probit") for r in with_lp),
        "brier": _avg(brier(r["option_probs"], r["correct_answer"]) for r in graded_lp if r.get("option_probs")),
        "ece": expected_calibration_error(conf, corr),
        "auroc": auroc(conf, corr),
        "agreement": agreement,
        "cost": sum(costs) if costs else None,
        "providers": sorted({r.get("provider") for r in ok if r.get("provider")}),
        **stated,
    }


def meta_keys(recs: list[dict]) -> list[str]:
    keys: list[str] = []
    for r in recs:
        for k in (r.get("meta") or {}):
            if k not in keys:
                keys.append(k)
    return keys


def write_csv(recs: list[dict], path: Path):
    mk = [k for k in meta_keys(recs) if k not in CSV_FIELDS]
    i = CSV_FIELDS.index("category") + 1
    fields = CSV_FIELDS[:i] + mk + CSV_FIELDS[i:]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in sorted(recs, key=lambda r: (r["model_id"], r["question_id"], r["repeat"])):
            row = dict(r)
            for k in mk:
                row[k] = (r.get("meta") or {}).get(k)
            if isinstance(row.get("option_probs"), dict):
                row["option_probs"] = json.dumps(row["option_probs"])
            w.writerow(row)


def breakdown_sections(recs: list[dict], order: list[str], labels: dict) -> list[str]:
    """Accuracy and mean confidence per value of each grouping column (species, risk, ...)."""
    ok = [r for r in recs if r["status"] == "ok"]
    groups = {}
    if any(r.get("category") for r in ok):
        groups["category"] = lambda r: r.get("category")
    for k in meta_keys(ok):
        groups[k] = lambda r, k=k: (r.get("meta") or {}).get(k)
    if any(r.get("correct_answer") for r in ok):
        groups["correct answer"] = lambda r: r.get("correct_answer")

    out = []
    for name, get in groups.items():
        values = sorted({get(r) for r in ok if get(r)})
        n_questions = len({r["question_id"] for r in ok})
        if not 2 <= len(values) <= 15 or len(values) >= n_questions:
            continue  # one value, or one per question: not a useful grouping
        out.append(f"\n### By {name.replace('_', ' ')}\n")
        head = ["Value", "n"] + [f"{labels[m]} acc. / conf." for m in order]
        out.append("| " + " | ".join(head) + " |")
        out.append("|" + "---|" * len(head))
        for v in values:
            sub = [r for r in ok if get(r) == v]
            cells = [str(v), str(len({r['question_id'] for r in sub}))]
            for m in order:
                s = [r for r in sub if r["model_id"] == m]
                graded = [r for r in s if r.get("is_correct") is not None]
                acc = (sum(r["is_correct"] for r in graded) / len(graded)) if graded else None
                cells.append(f"{_fmt(acc, pct=True)} / {_fmt(_avg(r.get('p_answer') for r in s))}")
            out.append("| " + " | ".join(cells) + " |")
    if out:
        out.insert(0, "\n## Breakdown\n\nAccuracy / mean confidence for each group.")
    return out


def build_report(run_dir: str | Path) -> Path:
    run_dir = Path(run_dir)
    recs = latest_records(run_dir / "raw.jsonl")
    if not recs:
        raise SystemExit(f"No results found in {run_dir / 'raw.jsonl'}")
    meta_path = run_dir / "run_meta.json"
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    write_csv(recs, run_dir / "summary.csv")

    labels = {}
    by_model = defaultdict(list)
    for r in recs:
        labels[r["model_id"]] = r.get("model_label") or r["model_id"]
        by_model[r["model_id"]].append(r)
    order = [m.get("id") for m in meta.get("config", {}).get("models", []) if m.get("id") in by_model]
    order += [m for m in by_model if m not in order]
    summaries = {m: model_summary(by_model[m]) for m in order}
    run_cfg = meta.get("config", {}).get("run", {})
    repeats = run_cfg.get("repeats", 1)

    L = []
    L.append(f"# LLM uncertainty test — {meta.get('run_name', run_dir.name)}\n")
    L.append(f"- **Questions:** `{meta.get('questions_file', '?')}` ({meta.get('n_questions', '?')} questions, "
             f"sha256 `{str(meta.get('questions_sha256', ''))[:12]}`)")
    L.append(f"- **Temperature:** {run_cfg.get('temperature', 0.0)} · **top_logprobs:** "
             f"{run_cfg.get('top_logprobs', 10)} · **repeats:** {repeats}")
    ns = meta.get("not_sure") or {}
    if ns.get("option"):
        line = (f"- **Not-sure option ({ns['option']}):** "
                f"{'offered to the model' if ns.get('offered', True) else 'hidden from the model'}")
        if ns.get("dropped_questions"):
            line += (f" · {len(ns['dropped_questions'])} question(s) skipped because their answer is "
                     f"{ns['option']}: {', '.join(ns['dropped_questions'])}")
        L.append(line)
    sessions = meta.get("sessions", [])
    if sessions:
        L.append(f"- **Run sessions:** {len(sessions)} (first started {sessions[0].get('started')}, "
                 f"last finished {sessions[-1].get('finished')})")
    if meta.get("git_commit"):
        L.append(f"- **Code version:** git `{meta['git_commit']}`")
    L.append(f"- **System prompt:** {run_cfg.get('system_prompt', '(default)')}\n")

    L.append("## Summary by model\n")
    head = ["Model", "OK", "Errors", "Logprobs", "Accuracy", "Mean conf.", "Conf. right",
            "Conf. wrong", "Entropy (bits)", "Mean probit", "Brier", "ECE", "AUROC"]
    any_ns = any(summaries[m]["not_sure_offered"] for m in order)
    if any_ns:
        head += ["Not sure chosen", "Mean p(not sure)", "Acc. when answered"]
    if repeats > 1:
        head.append("Agreement")
    head.append("Cost ($)")
    L.append("| " + " | ".join(head) + " |")
    L.append("|" + "---|" * len(head))
    for m in order:
        s = summaries[m]
        row = [labels[m], str(s["calls_ok"]), str(s["errors"]), _fmt(s["logprob_rate"], pct=True),
               _fmt(s["accuracy"], pct=True), _fmt(s["mean_conf"]), _fmt(s["conf_right"]),
               _fmt(s["conf_wrong"]), _fmt(s["mean_entropy"]), _fmt(s["mean_probit"], 2),
               _fmt(s["brier"]), _fmt(s["ece"]), _fmt(s["auroc"])]
        if any_ns:
            row += [_fmt(s["not_sure_rate"], pct=True), _fmt(s["mean_p_not_sure"]),
                    _fmt(s["acc_answered"], pct=True)]
        if repeats > 1:
            row.append(_fmt(s["agreement"], pct=True))
        row.append(_fmt(s["cost"], 5))
        L.append("| " + " | ".join(row) + " |")
    for m in order:
        if summaries[m]["providers"]:
            L.append(f"\n_{labels[m]} served by: {', '.join(summaries[m]['providers'])}_")

    if any(summaries[m]["stated_asked"] for m in order):
        L.append("\n## Stated vs token confidence\n")
        L.append("After answering, each model was asked how confident it was (0-100). "
                 "This compares what it *says* with the probability it actually put on its answer.\n")
        h2 = ["Model", "Accuracy", "Token conf.", "Stated conf.", "Stated: right", "Stated: wrong",
              "ECE token", "ECE stated", "AUROC token", "AUROC stated", "ρ token↔stated",
              "Parsed", "Distinct values"]
        L.append("| " + " | ".join(h2) + " |")
        L.append("|" + "---|" * len(h2))
        for m in order:
            s = summaries[m]
            L.append("| " + " | ".join([labels[m], _fmt(s["accuracy"], pct=True), _fmt(s["mean_conf"]),
                     _fmt(s["mean_stated"]), _fmt(s["stated_right"]), _fmt(s["stated_wrong"]),
                     _fmt(s["ece"]), _fmt(s["ece_stated"]), _fmt(s["auroc"]), _fmt(s["auroc_stated"]),
                     _fmt(s["rho_token_stated"], 2), _fmt(s["stated_rate"], pct=True),
                     str(s["distinct_stated"])]) + " |")

    L.append("\n### How to read this\n")
    L.append("- **Conf. (p)** – probability the model put on the option it chose, renormalised over the "
             "valid option letters. 1.0 = certain.")
    L.append("- **Probit** – Φ⁻¹(p): the confidence on a z-score scale (0 = 50/50, 2.33 ≈ 99%).")
    L.append("- **Entropy** – spread of probability across options (0 = all on one; log2(#options) = uniform).")
    L.append("- **Brier** – squared error of the full option distribution vs the right answer (lower is better).")
    L.append("- **ECE** – expected calibration error: gap between confidence and actual accuracy (lower is better).")
    L.append("- **AUROC** – how well confidence separates right from wrong answers (0.5 = chance, 1.0 = perfect).")
    L.append("- **Stated conf.** – the 0-100 number the model gave when asked how sure it was, as 0-1. "
             "**ρ token↔stated** – rank correlation between the two kinds of confidence (1 = same ordering). "
             "**Distinct values** – how many different numbers it used; small models often say 90 to everything.")
    if any_ns:
        L.append("- **Not sure chosen** – share of questions where the model picked the not-sure option.")
        L.append("- **Mean p(not sure)** – average probability on the not-sure option, even when not picked.")
        L.append("- **Acc. when answered** – accuracy on the questions where it did not pick not-sure.")
    if repeats > 1:
        L.append("- **Agreement** – share of repeated samples that match the most common answer.")

    L.extend(breakdown_sections(recs, order, labels))

    L.append("\n## Per-question results\n")
    L.append("Each cell: answer, ✓/✗ if graded, token confidence p, and stated confidence (if asked).\n")
    qids = []
    qinfo = {}
    for r in sorted(recs, key=lambda r: r["question_id"]):
        if r["question_id"] not in qinfo:
            qids.append(r["question_id"])
            qinfo[r["question_id"]] = r
    L.append("| Question | Correct | " + " | ".join(labels[m] for m in order) + " |")
    L.append("|---|---|" + "---|" * len(order))
    cell_index = defaultdict(list)
    for r in recs:
        cell_index[(r["model_id"], r["question_id"])].append(r)
    for qid in qids:
        q = qinfo[qid]
        text = (q.get("question") or "").replace("|", "\\|").replace("\n", " ")
        if len(text) > 70:
            text = text[:67] + "..."
        cells = []
        for m in order:
            rs = [r for r in cell_index[(m, qid)] if r["status"] == "ok"]
            if not rs:
                cells.append("error" if cell_index[(m, qid)] else "–")
                continue
            answers = Counter(r.get("answer") for r in rs)
            ans, cnt = answers.most_common(1)[0]
            p = _avg(r.get("p_answer") for r in rs if r.get("answer") == ans)
            mark = ""
            if any(r.get("abstained") and r.get("answer") == ans for r in rs):
                mark = " (not sure)"
            elif q.get("correct_answer"):
                mark = " ✓" if ans == q["correct_answer"] else " ✗"
            extra = f" ({cnt}/{len(rs)})" if len(rs) > 1 else ""
            sc = _avg(r.get("stated_conf") for r in rs if r.get("answer") == ans)
            stxt = f" · says {_fmt(sc, 2)}" if sc is not None else ""
            cells.append(f"{ans or '?'}{mark} {_fmt(p)}{stxt}{extra}")
        L.append(f"| **{qid}** {text} | {q.get('correct_answer') or '–'} | " + " | ".join(cells) + " |")

    errors = [r for r in recs if r["status"] != "ok"]
    if errors:
        L.append("\n## Errors\n")
        L.append("These calls failed after retries. Re-run with the same `--name` to retry only these.\n")
        for r in errors[:50]:
            L.append(f"- `{labels[r['model_id']]}` / `{r['question_id']}` r{r['repeat']}: {r.get('error')}")
        if len(errors) > 50:
            L.append(f"- …and {len(errors) - 50} more (see summary.csv)")

    L.append("\n---\nFiles in this folder: `raw.jsonl` (every API call, including raw responses), "
             "`summary.csv` (one row per answer), `run_meta.json` (config and run history).")
    out = run_dir / "report.md"
    out.write_text("\n".join(L) + "\n", encoding="utf-8")
    return out
