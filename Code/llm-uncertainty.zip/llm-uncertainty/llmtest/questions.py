"""Read question sets from CSV or JSONL.

CSV columns (either naming style works):
    id | question_id                       question
    A, B, C ... | option_a, option_b ...   answer | correct_option | correct_answer   (optional)
    any other columns (category, species, clinical_risk, ...) are kept as metadata and
    appear in summary.csv and the report's breakdown tables.
JSONL fields:  {"id": "q1", "question": "...", "options": {"A": "...", "B": "..."}, "answer": "B", ...}
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

ID_COLS = ("id", "question_id", "qid")
ANSWER_COLS = ("answer", "correct_option", "correct_answer", "correct")
_OPTION_COL = re.compile(r"^(?:option[ _]?([a-z])|([A-Z]))$", re.IGNORECASE)


def _option_letter(col: str) -> str | None:
    m = _OPTION_COL.match(col.strip())
    if not m:
        return None
    if m.group(1):
        return m.group(1).upper()
    return m.group(2) if m.group(2).isupper() else None   # bare "A" yes, bare "a" no


@dataclass
class Question:
    id: str
    question: str
    options: dict[str, str]          # {"A": "Sydney", "B": "Canberra", ...}
    answer: str | None = None        # correct letter, if known
    category: str | None = None
    meta: dict[str, str] = field(default_factory=dict)   # extra columns, e.g. species, clinical_risk

    @property
    def letters(self) -> list[str]:
        return list(self.options)

    def to_prompt(self) -> str:
        lines = [self.question.strip(), ""]
        lines += [f"{k}) {v}" for k, v in self.options.items()]
        return "\n".join(lines)


def _clean_answer(ans, options) -> str | None:
    if ans is None:
        return None
    ans = str(ans).strip().upper()
    if not ans:
        return None
    if ans not in options:
        raise ValueError(f"answer {ans!r} is not one of the options {list(options)}")
    return ans


def load_questions(path: str | Path) -> list[Question]:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        qs = _load_csv(path)
    elif path.suffix.lower() in (".jsonl", ".ndjson"):
        qs = _load_jsonl(path)
    else:
        raise ValueError("questions file must be .csv or .jsonl")

    seen = set()
    for q in qs:
        if q.id in seen:
            raise ValueError(f"duplicate question id {q.id!r} in {path}")
        seen.add(q.id)
        if len(q.options) < 2:
            raise ValueError(f"question {q.id!r} needs at least two options")
    return qs


def _load_csv(path: Path) -> list[Question]:
    out = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        cols = [c for c in (reader.fieldnames or []) if c is not None]
        option_cols = {c: _option_letter(c) for c in cols if _option_letter(c)}
        option_cols = dict(sorted(option_cols.items(), key=lambda kv: kv[1]))
        if not option_cols:
            raise ValueError("CSV needs option columns named A, B, C, ... or option_a, option_b, ...")
        if "question" not in cols:
            raise ValueError("CSV needs a 'question' column")
        id_col = next((c for c in ID_COLS if c in cols), None)
        ans_col = next((c for c in ANSWER_COLS if c in cols), None)
        used = set(option_cols) | {"question", "category", id_col, ans_col}
        meta_cols = [c for c in cols if c not in used]
        for i, row in enumerate(reader, start=1):
            if not (row.get("question") or "").strip():
                continue
            options = {L: row[c].strip() for c, L in option_cols.items() if (row.get(c) or "").strip()}
            out.append(Question(
                id=((row.get(id_col) if id_col else None) or f"q{i}").strip(),
                question=row["question"],
                options=options,
                answer=_clean_answer(row.get(ans_col) if ans_col else None, options),
                category=(row.get("category") or "").strip() or None,
                meta={c: (row.get(c) or "").strip() for c in meta_cols},
            ))
    return out


def _load_jsonl(path: Path) -> list[Question]:
    out = []
    with path.open(encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            if not line.strip():
                continue
            d = json.loads(line)
            options = {str(k).upper(): str(v) for k, v in d["options"].items()}
            known = {"id", "question", "options", "answer", "category"}
            out.append(Question(
                id=str(d.get("id", f"q{i}")),
                question=d["question"],
                options=options,
                answer=_clean_answer(d.get("answer"), options),
                category=d.get("category"),
                meta={k: str(v) for k, v in d.items() if k not in known},
            ))
    return out


def apply_not_sure(questions: list[Question], letter: str, offer: bool) -> tuple[list[Question], list[str]]:
    """Offer or hide the 'not sure' option.

    When hidden, that option is removed from every question. A question whose correct answer *is*
    the not-sure option can't be answered without it, so it is dropped; its id is returned.
    """
    if offer or not letter:
        return questions, []
    kept, dropped = [], []
    for q in questions:
        if letter not in q.options:
            kept.append(q)
        elif q.answer == letter:
            dropped.append(q.id)
        else:
            kept.append(Question(id=q.id, question=q.question,
                                 options={k: v for k, v in q.options.items() if k != letter},
                                 answer=q.answer, category=q.category, meta=dict(q.meta)))
    return kept, dropped


def file_sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
