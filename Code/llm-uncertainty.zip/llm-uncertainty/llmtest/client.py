"""OpenRouter client with pacing, retries and clear errors."""
from __future__ import annotations

import random
import time

import openai
from openai import OpenAI

RETRYABLE = (
    openai.RateLimitError,
    openai.APIConnectionError,
    openai.APITimeoutError,
    openai.InternalServerError,
)


class EmptyResponse(Exception):
    """OpenRouter sometimes returns HTTP 200 with an error body and no choices."""


class DailyLimitReached(Exception):
    """The account's free-model daily quota is used up; retrying today won't help."""


class ModelUnavailable(Exception):
    """A model can't be used at all (failed to load, doesn't exist); skip it for this run."""


def _retry_after_seconds(exc) -> float | None:
    resp = getattr(exc, "response", None)
    headers = getattr(resp, "headers", None)
    if not headers:
        return None
    ra = headers.get("retry-after")
    if ra:
        try:
            return float(ra)
        except ValueError:
            pass
    reset = headers.get("x-ratelimit-reset")  # OpenRouter: epoch milliseconds
    if reset:
        try:
            return max(0.0, float(reset) / 1000 - time.time())
        except ValueError:
            pass
    return None


class OpenRouterClient:
    def __init__(self, api_key: str, base_url: str, requests_per_minute: float = 18,
                 max_retries: int = 6, timeout: float = 120, require_parameters: bool = True,
                 log=print):
        self.client = OpenAI(
            api_key=api_key, base_url=base_url, max_retries=0, timeout=timeout,
            default_headers={"X-Title": "llm-uncertainty"},
        )
        self.min_interval = 60.0 / requests_per_minute if requests_per_minute else 0.0
        self.max_retries = max_retries
        self.require_parameters = require_parameters
        self.log = log
        self._last_call = 0.0

    def _pace(self):
        wait = self._last_call + self.min_interval - time.monotonic()
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()

    def chat(self, *, model: str, messages: list[dict], temperature: float, max_tokens: int,
             top_logprobs: int, reasoning: dict | None = None):
        """Returns (response, attempts_used). Raises after max_retries."""
        extra_body = {"usage": {"include": True}}
        if self.require_parameters:
            # only route to providers that support every parameter we send (i.e. logprobs)
            extra_body["provider"] = {"require_parameters": True}
        if reasoning:
            extra_body["reasoning"] = reasoning

        attempt = 0
        while True:
            self._pace()
            try:
                resp = self.client.chat.completions.create(
                    model=model, messages=messages, temperature=temperature,
                    max_tokens=max_tokens, logprobs=True,
                    top_logprobs=top_logprobs if top_logprobs else None,
                    extra_body=extra_body,
                )
                if not getattr(resp, "choices", None):
                    err = (getattr(resp, "model_extra", None) or {}).get("error")
                    raise EmptyResponse(f"no choices returned: {err}")
                return resp, attempt + 1
            except openai.RateLimitError as e:
                msg = str(e).lower()
                if "per-day" in msg or "per day" in msg:
                    raise DailyLimitReached(str(e)) from e
                attempt = self._backoff(e, attempt)
            except (RETRYABLE + (EmptyResponse,)) as e:
                attempt = self._backoff(e, attempt)

    def _backoff(self, exc, attempt: int) -> int:
        attempt += 1
        if attempt > self.max_retries:
            raise exc
        delay = _retry_after_seconds(exc)
        if delay is None:
            delay = min(60.0, 2.0 ** attempt) + random.uniform(0, 1)
        delay = min(delay, 300.0)
        self.log(f"    retry {attempt}/{self.max_retries} in {delay:.1f}s ({type(exc).__name__}: {str(exc)[:120]})")
        time.sleep(delay)
        return attempt
