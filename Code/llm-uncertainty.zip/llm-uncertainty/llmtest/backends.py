"""Pick the client for the configured backend."""
from __future__ import annotations

import os

from .config import Config


def make_client(cfg: Config, log=print):
    if cfg.backend == "huggingface":
        from .hf_client import HFClient
        return HFClient(cfg.models, log=log)

    from .client import OpenRouterClient
    api_key = os.environ.get(cfg.api_key_env)
    if not api_key:
        raise SystemExit(f"Set {cfg.api_key_env} (in your environment or a .env file). See .env.example.")
    return OpenRouterClient(api_key=api_key, base_url=cfg.base_url,
                            requests_per_minute=cfg.requests_per_minute, max_retries=cfg.max_retries,
                            timeout=cfg.timeout_seconds, require_parameters=cfg.require_parameters, log=log)
