"""Turn token logprobs into uncertainty measures, and aggregate them per model."""
from __future__ import annotations

import math
import re
from statistics import NormalDist

_LETTER_TOKEN = re.compile(r"""^[\s*_(\["'`]*([A-Z])[\s*_)\].:,"'`]*$""")
_LETTER_IN_TEXT = re.compile(r"\b([A-Z])\b")
_EPS = 1e-6


def token_letter(token: str, letters) -> str | None:
    """Return the option letter a token stands for (' B', 'B)', '**B' -> 'B'), else None."""
    m = _LETTER_TOKEN.match(token or "")
    if m and m.group(1) in letters:
        return m.group(1)
    return None


def letter_from_text(text: str, letters) -> str | None:
    for m in _LETTER_IN_TEXT.finditer(text or ""):
        if m.group(1) in letters:
            return m.group(1)
    return None


def _get(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def find_answer_position(content_logprobs, letters):
    """Index of the first generated token that is an option letter."""
    for i, entry in enumerate(content_logprobs or []):
        if token_letter(_get(entry, "token"), letters):
            return i
    return None


def option_distribution(entry, letters):
    """Probability mass on each option letter at one token position.

    Returns (raw_mass, total_mass, normalised) where `normalised` sums to 1 over the options.
    Token variants such as 'B' and ' B' are summed together.
    """
    mass = {L: 0.0 for L in letters}
    seen = set()
    candidates = list(_get(entry, "top_logprobs") or []) + [entry]
    for c in candidates:
        tok = _get(c, "token")
        if tok in seen:
            continue
        seen.add(tok)
        L = token_letter(tok, letters)
        lp = _get(c, "logprob")
        if L and lp is not None and lp > -1000:
            mass[L] += math.exp(lp)
    total = sum(mass.values())
    norm = {L: v / total for L, v in mass.items()} if total > 0 else {}
    return mass, total, norm


def entropy_bits(dist: dict[str, float]) -> float | None:
    if not dist:
        return None
    return -sum(p * math.log2(p) for p in dist.values() if p > 0)


def probit(p: float | None) -> float | None:
    """Inverse standard-normal CDF of p (clipped away from 0 and 1)."""
    if p is None:
        return None
    return NormalDist().inv_cdf(min(max(p, _EPS), 1 - _EPS))


def margin(dist: dict[str, float]) -> float | None:
    if len(dist) < 2:
        return None
    top = sorted(dist.values(), reverse=True)
    return top[0] - top[1]


def analyse(content: str, content_logprobs, letters) -> dict:
    """All per-response metrics from the returned text + logprobs."""
    out = {
        "answer": None, "logprobs_available": bool(content_logprobs),
        "p_token": None, "p_answer": None, "probit": None,
        "option_probs": {}, "option_mass": None,
        "entropy_bits": None, "norm_entropy": None, "margin": None,
    }
    pos = find_answer_position(content_logprobs, letters)
    if pos is None:
        out["answer"] = letter_from_text(content, letters)
        return out

    entry = content_logprobs[pos]
    answer = token_letter(_get(entry, "token"), letters)
    _, total, norm = option_distribution(entry, letters)
    h = entropy_bits(norm)
    out.update(
        answer=answer,
        p_token=math.exp(_get(entry, "logprob")),
        p_answer=norm.get(answer),
        option_probs={k: round(v, 6) for k, v in norm.items()},
        option_mass=round(total, 6),
        entropy_bits=h,
        norm_entropy=(h / math.log2(len(letters))) if h is not None and len(letters) > 1 else None,
        margin=margin(norm),
    )
    out["probit"] = probit(out["p_answer"])
    return out


# ---------- aggregate metrics over many responses ----------

def brier(option_probs: dict[str, float], correct: str) -> float:
    return sum((p - (1.0 if k == correct else 0.0)) ** 2 for k, p in option_probs.items())


def expected_calibration_error(confidences, corrects, bins: int = 10) -> float | None:
    pairs = [(c, y) for c, y in zip(confidences, corrects) if c is not None and y is not None]
    if not pairs:
        return None
    n = len(pairs)
    ece = 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        bucket = [(c, y) for c, y in pairs if (lo < c <= hi) or (b == 0 and c == 0)]
        if bucket:
            acc = sum(y for _, y in bucket) / len(bucket)
            conf = sum(c for c, _ in bucket) / len(bucket)
            ece += len(bucket) / n * abs(acc - conf)
    return ece


def auroc(confidences, corrects) -> float | None:
    """How well confidence separates right from wrong answers (0.5 = no better than chance)."""
    pos = [c for c, y in zip(confidences, corrects) if y is True and c is not None]
    neg = [c for c, y in zip(confidences, corrects) if y is False and c is not None]
    if not pos or not neg:
        return None
    wins = 0.0
    for p in pos:
        for q in neg:
            wins += 1.0 if p > q else 0.5 if p == q else 0.0
    return wins / (len(pos) * len(neg))


def parse_stated_confidence(text: str | None) -> float | None:
    """First number in the model's reply, as a probability in [0, 1]. '85', '85%', '0.85' -> 0.85."""
    import re as _re
    if not text:
        return None
    hit = _re.search(r"\d+(?:\.\d+)?", text)
    if not hit:
        return None
    v = float(hit.group())
    if v <= 1 and "." in hit.group():   # answered on a 0-1 scale
        v *= 100
    return max(0.0, min(100.0, v)) / 100


def spearman(xs, ys) -> float | None:
    """Rank correlation between two equal-length lists (ties get average ranks)."""
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    if len(pairs) < 3:
        return None

    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and v[order[j + 1]] == v[order[i]]:
                j += 1
            for k in range(i, j + 1):
                r[order[k]] = (i + j) / 2 + 1
            i = j + 1
        return r

    rx, ry = ranks([p[0] for p in pairs]), ranks([p[1] for p in pairs])
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return num / den if den else None
