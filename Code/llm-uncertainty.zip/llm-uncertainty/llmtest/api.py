"""Use the test from your own Python code (or a notebook):

    from llmtest.api import run_questions
    run_dir = run_questions("questions/example.csv", config_path="config.colab.toml")
    print((run_dir / "report.md").read_text())
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .backends import make_client
from .config import load_config
from .questions import apply_not_sure, load_questions
from .report import build_report
from .runner import run_test


def run_questions(questions_path: str | Path, config_path: str | Path = "config.toml",
                  name: str | None = None, out: str | Path = "results",
                  models: list[str] | None = None, offer_not_sure: bool | None = None,
                  log=print) -> Path:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    cfg = load_config(config_path)
    if models:
        cfg.models = [m for m in cfg.models if m.id in models or m.label in models]
        if not cfg.models:
            raise ValueError(f"None of {models} are in {config_path}")
    qpath = Path(questions_path)
    if offer_not_sure is not None:
        cfg.offer_not_sure = offer_not_sure
    questions, dropped = apply_not_sure(load_questions(qpath), cfg.not_sure_option, cfg.offer_not_sure)
    if dropped:
        log(f"Skipping {len(dropped)} question(s) whose answer is the hidden option: {', '.join(dropped)}")
    client = make_client(cfg, log=log)
    name = name or f"{datetime.now():%Y-%m-%d_%H%M}_{qpath.stem}"
    out_dir = Path(out) / name
    run_test(cfg, questions, qpath, out_dir, client, name, log=log, dropped=dropped)
    if (out_dir / "raw.jsonl").exists():
        build_report(out_dir)
    return out_dir
