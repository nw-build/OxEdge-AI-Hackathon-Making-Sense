"""Command line:  python -m llmtest {run,report,models} ..."""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
from datetime import datetime
from pathlib import Path

from .config import load_config
from .questions import apply_not_sure, load_questions

FREE_DAILY_LIMIT_HINT = 50


def _load_env():
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass


def cmd_run(args):
    _load_env()
    cfg = load_config(args.config)
    if args.models:
        wanted = [m.strip() for m in args.models.split(",")]
        cfg.models = [m for m in cfg.models if m.id in wanted or m.label in wanted]
        if not cfg.models:
            sys.exit(f"None of {wanted} are in {args.config}")
    if args.not_sure:
        cfg.offer_not_sure = args.not_sure == "offer"
    qpath = Path(args.questions)
    questions = load_questions(qpath)
    if args.limit:
        questions = questions[: args.limit]
    questions, dropped = apply_not_sure(questions, cfg.not_sure_option, cfg.offer_not_sure)
    if cfg.not_sure_option:
        print(f"Not-sure option ({cfg.not_sure_option}): {'offered to the model' if cfg.offer_not_sure else 'hidden'}")
    if dropped:
        print(f"Skipping {len(dropped)} question(s) whose correct answer is the hidden option "
              f"{cfg.not_sure_option}: {', '.join(dropped)}")
    if not questions:
        sys.exit("No questions left to ask.")

    n_calls = len(cfg.models) * len(questions) * cfg.repeats
    print(f"{len(questions)} questions × {len(cfg.models)} models × {cfg.repeats} repeats = {n_calls} model calls")
    free = [m.id for m in cfg.models if m.id.endswith(":free")]
    if cfg.backend == "openrouter" and free and n_calls > FREE_DAILY_LIMIT_HINT:
        print(f"Note: free models are capped per day (50/day, or 1,000/day after a one-off $10 credit "
              f"purchase). The run will stop cleanly at the cap and can be resumed with --name.")
    if args.dry_run:
        print("\nDry run — first prompt would be:\n")
        print(f"[system] {cfg.system_prompt}\n[user] {questions[0].to_prompt()}")
        return

    from .backends import make_client
    from .report import build_report
    from .runner import run_test

    client = make_client(cfg)
    name = args.name or f"{datetime.now():%Y-%m-%d_%H%M}_{qpath.stem}"
    out_dir = Path(args.out) / name
    print(f"Backend: {cfg.backend} · results folder: {out_dir}")
    session = run_test(cfg, questions, qpath, out_dir, client, name, dropped=dropped)
    print(f"\nSession: {session['ok']} ok, {session['errors']} errors, "
          f"{session['skipped_already_done']} already done")
    if (out_dir / "raw.jsonl").exists():
        report = build_report(out_dir)
        print(f"Report: {report}")
    if session["errors"] or session["stopped_reason"]:
        print(f"To retry failed/remaining calls: python -m llmtest run --questions {qpath} "
              f"--config {args.config} --name {name}")


def cmd_report(args):
    from .report import build_report
    print(build_report(args.run_dir))


def cmd_models(args):
    url = "https://openrouter.ai/api/v1/models"
    with urllib.request.urlopen(url, timeout=30) as r:
        data = json.load(r)["data"]
    rows = []
    for m in data:
        sp = m.get("supported_parameters") or []
        if not args.all and "logprobs" not in sp:
            continue
        if args.free and not m["id"].endswith(":free"):
            continue
        if args.search and args.search.lower() not in m["id"].lower():
            continue
        p = m.get("pricing", {})
        pin = float(p.get("prompt") or 0) * 1e6
        pout = float(p.get("completion") or 0) * 1e6
        rows.append((m["id"], pin, pout, "logprobs" in sp))
    rows.sort()
    print(f"{'model id':60} {'$/M in':>8} {'$/M out':>8}  logprobs")
    for mid, pin, pout, lp in rows:
        print(f"{mid:60} {pin:8.3f} {pout:8.3f}  {'yes' if lp else 'no'}")
    print(f"\n{len(rows)} models. 'logprobs' = at least one provider supports it.")


def main(argv=None):
    p = argparse.ArgumentParser(prog="llmtest", description="LLM uncertainty tests via OpenRouter")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="ask every model every question and record logprobs")
    r.add_argument("--questions", "-q", required=True, help="questions .csv or .jsonl")
    r.add_argument("--config", "-c", default="config.toml")
    r.add_argument("--name", "-n", help="run name (re-use it to resume an unfinished run)")
    r.add_argument("--out", default="results", help="parent folder for results")
    r.add_argument("--models", help="comma-separated subset of model ids/labels from the config")
    r.add_argument("--limit", type=int, help="only the first N questions (for a quick test)")
    r.add_argument("--not-sure", choices=["offer", "hide"],
                   help="show or remove the 'not sure' option (default: config [run] offer_not_sure)")
    r.add_argument("--dry-run", action="store_true", help="validate inputs and show the prompt; no API calls")
    r.set_defaults(func=cmd_run)

    rp = sub.add_parser("report", help="rebuild report.md and summary.csv for a run folder")
    rp.add_argument("run_dir")
    rp.set_defaults(func=cmd_report)

    m = sub.add_parser("models", help="list OpenRouter models that return logprobs")
    m.add_argument("--free", action="store_true", help="only :free models")
    m.add_argument("--all", action="store_true", help="include models without logprobs")
    m.add_argument("--search", help="filter ids by text, e.g. deepseek")
    m.set_defaults(func=cmd_models)

    args = p.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
