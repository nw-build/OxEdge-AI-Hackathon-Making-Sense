"""llmtest: run multiple-choice uncertainty tests against LLMs via OpenRouter and record token probabilities."""

__version__ = "0.1.0"
